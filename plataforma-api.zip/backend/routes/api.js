const express = require('express');
const User = require('../models/User');
const router = express.Router();

router.get('/teste', async (req, res) => {
  const key = req.query.apikey;
  const user = await User.findOne({ apiKey: key });
  if (!user) return res.status(403).json({ msg: 'API Key inválida' });
  if (user.usage >= user.limit) return res.status(429).json({ msg: 'Limite atingido' });

  user.usage += 1;
  await user.save();

  res.json({ msg: 'Requisição bem-sucedida' });
});

module.exports = router;