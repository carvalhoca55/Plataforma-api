# Plataforma de Venda de APIs

## Funcionalidades
- Registro/Login de usuários
- Geração de chave de API única
- Controle de limite de requisições
- Validação de chave nas rotas
- Painel HTML simples com info da API
- Pix manual (com upgrade manual pelo admin)

## Instruções
1. Copie `.env.example` para `.env` e preencha com seus dados MongoDB e JWT
2. Execute `npm install` na pasta `backend`
3. Inicie com `node index.js`
4. Acesse o frontend abrindo `frontend/index.html`

Pronto para customizar e vender suas APIs.